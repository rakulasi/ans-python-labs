"""
Unit tests for the JSON to PDF application
""" 